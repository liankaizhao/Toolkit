package cn.witsky.utils.time;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author zhaoliancan
 * @description 时间处理工具类
 * @create 2019-05-10 17:26
 */
public class DateUtils {
    private static  final ThreadLocal<DateFormat> threadLocal = new ThreadLocal<DateFormat>();
    public static DateFormat getDateFormat(String dateFormat)
    {

        DateFormat df = threadLocal.get();
        if(df==null){
            df = new SimpleDateFormat(dateFormat);
            threadLocal.set(df);
        }
        return df;
    }



    /**
     * 日期格式化
     * @param dateFormat 格式化参数
     * @param date 日期
     * @return  格式化后的日期
     * @throws ParseException
     */
    public static String formatDate(String dateFormat,Date date) throws ParseException {
        return getDateFormat(dateFormat).format(date);
    }

    /**
     * 将不同时区时间格式化
     * @param string
     * @return
     */
    public static synchronized Date formatDate(String string) {
        SimpleDateFormat resultSdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        SimpleDateFormat resultSdfdate = new SimpleDateFormat("yyyy-MM-dd");
        if (string != null) {
            if (string.contains("CST")) {
                long d2 = Date.parse(string);
                Date datetime = new Date(d2);

                return datetime;

            } else if (string.contains("Z")) {
                SimpleDateFormat sdf = new SimpleDateFormat(
                        "yyyy-MM-dd'T'hh:mm:ss'.'sss'Z'");
                java.util.Date datetime;
                try {
                    datetime = sdf.parse(string);
                    return (Date) datetime;
                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            } else if (string.contains("-")&&string.contains(":")) {
                Date newDate;
                try {
                    newDate = resultSdf.parse(string);
                    return newDate;
                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } else if(string.contains("-")&&!string.contains(":")){
                Date newDate;
                try {
                    newDate = resultSdfdate.parse(string);
                    return newDate;
                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }else {
                Date longDate = new Date(Long.parseLong(string));

                return longDate;
            }
        }
        return null;
    }

    /**
     * 获取与当前月份相差为i的月份
     * @param i
     * @return
     */
    public static String getPerFirstYueOfMonth(int i) {
        DateFormat dft =getDateFormat("yyyy-MM");
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, i);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        return dft.format(calendar.getTime());
    }

    /**
     * 获取与当前日期相差为i的日期
     * @param i
     * @return
     */
    public static String getFirstDay(int i) {
        DateFormat dft = getDateFormat("yyyy-MM-dd");
        Calendar ca = Calendar.getInstance();
        ca.setTime(new Date());
        ca.add(Calendar.DATE, i);
        return dft.format(ca.getTime());
    }

    /**
     * 获取本月第一天
     * @return 当月1号
     */
    public static String getFirstDay() {
        DateFormat dft = getDateFormat("yyyy-MM-dd");
        Calendar cale = Calendar.getInstance();
        cale.add(Calendar.MONTH, 0);
        cale.set(Calendar.DAY_OF_MONTH, 1);
        return dft.format(cale.getTime());
    }

    /**
     * .根据当前时间生成cron表达式
     * @param date
     * @return cron表达式
     * @throws ParseException
     */
    public static String getCron(Date date) throws ParseException {
        String dateFormat = "ss mm HH dd MM ? yyyy";
        return formatDate(dateFormat, date);
    }


    /**
     * 时间相减得到天数
     * @param beginDateStr 开始日期
     * @param endDateStr  结束日期
     * @return 相隔天数
     */
    public static long getDaySub(String beginDateStr,String endDateStr){
        long day=0;
        DateFormat sdf=getDateFormat("yyyy-MM-dd");
        Date beginDate;
        Date endDate;
        try {
            beginDate = sdf.parse(beginDateStr);
            endDate= sdf.parse(endDateStr);
            day=(endDate.getTime()-beginDate.getTime())/(24*60*60*1000);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return day;

    }

    /**
     * 获取当天零点时间
     * @return
     */
    public static Date initDateByDay(){
        Calendar calendar1 = Calendar.getInstance();
        calendar1.set(calendar1.get(Calendar.YEAR), calendar1.get(Calendar.MONTH), calendar1.get(Calendar.DAY_OF_MONTH),
                0, 0, 0);
        return calendar1.getTime();
    }

    /**
     * 获取当天23点59分59秒
     * @return
     */
    public static Date initDateByDay1(){
        Calendar calendar = Calendar.getInstance();
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH),
                23, 59, 59);
        return calendar.getTime();
    }


    public static void main(String[] args) {
        Date date=new Date();
        String montn= null;
        String days=getFirstDay();
        System.out.println(days);
        try {
            montn = getCron(date);
            System.out.println(montn);
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }




}
