package cn.witsky.utils.string;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;
import java.util.Random;

import static java.util.Objects.isNull;

/**
 * @author zhaoliancan
 * @description 字符串工具类
 * @create 2019-05-10 17:25
 */
public class StringUtils {

    private final static Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    /**
     * List object to String
     *
     * @param mList
     * @return
     */
    public static String listToString(List<String> mList) {
        String convertedListStr = "";
        if (null != mList && mList.size() > 0) {
            String[] mListArray = mList.toArray(new String[mList.size()]);
            for (int i = 0; i < mListArray.length; i++) {
                if (i < mListArray.length - 1) {
                    convertedListStr += mListArray[i] + ",";
                } else {
                    convertedListStr += mListArray[i];
                }
            }
            return convertedListStr;
        } else return "List is null!!!";
    }

    /**
     * Generate a random number string
     *
     * @param num string's length
     * @return random number string
     */
    public static String getRandomString(Integer num) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < num; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    /**
     * Determine if two strings are equal
     *
     * @param s1
     * @param s2
     * @return
     */
    public static boolean equals(String s1, String s2) {
        if (isNull(s1)) {
            if (isNull(s2)) {
                return true;
            }
        } else if (!isNull(s2) && (s1 == s2 || s1.equals(s2))) {
            return true;
        }
        return false;
    }

    /**
     * Object to JSON string
     * @param bean Object
     * @return  JSON string
     */
    public static String toJson(Object bean) {
        return GSON.toJson(bean);
    }


}
