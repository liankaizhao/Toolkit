package cn.witsky.utils.collections;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author zhaoliancan
 * @description Map工具类
 * @create 2019-05-15 17:30
 */
public class MapUtils {

    /**
     * map按key排序
     * @param map
     * @return
     */
    public static synchronized Map<String, Integer> sortMapByKey(Map<String, Integer> map) {
        if (map == null || map.isEmpty()) {
            return null;
        }

        Map<String, Integer> sortMap = new TreeMap<String, Integer>(
                new MapKeyComparator());

        sortMap.putAll(map);
        return sortMap;
    }


    private static class MapKeyComparator implements Comparator<String>{
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        @Override
        public int compare(String str1, String str2) {
            try {
                Date time1=format.parse(str1);
                Date time2=format.parse(str2);
                return time1.compareTo(time2);
            } catch (ParseException e) {
                e.printStackTrace();
                return 0;
            }
        }
    }

    private static class MapValueComparator implements Comparator<Map.Entry<String, Integer>> {

        @Override
        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
            return o2.getValue().compareTo(o1.getValue());
        }


    }


    /**
     * map 按value排序
     * @param oriMap
     * @return
     */
    public static synchronized Map<String, Integer> sortMapByValue(Map<String, Integer> oriMap) {
        if (oriMap == null || oriMap.isEmpty()) {
            return null;
        }
        Map<String, Integer> sortedMap = new LinkedHashMap<>();
        List<Map.Entry<String, Integer>> entryList = new ArrayList<>(
                oriMap.entrySet());
        Collections.sort(entryList, new MapValueComparator());

        Iterator<Map.Entry<String, Integer>> iter = entryList.iterator();
        Map.Entry<String, Integer> tmpEntry = null;
        while (iter.hasNext()) {
            tmpEntry = iter.next();
            sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());
        }
        return sortedMap;
    }
}
