package cn.witsky.utils.file;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author zhaoliancan
 * @description 文件处理工具类
 * @create 2019-05-16 9:58
 */
public class FileUtils {

    /**
     * 把文件从原始路径拷贝到新路径下并删除原来路径下的文件
     * @param oldFile 原有文件
     * @param newPath 新路径
     * @param fileName 文件名
     * @throws Exception
     */
    public static void transferFile(File oldFile, String newPath, String fileName) throws Exception {
        File files = new File(newPath);
        if(!files.isFile()){
            files.mkdir();
        }

        int byteread = 0;
        FileInputStream fin = null;
        FileOutputStream fout = null;
        try{
            if(oldFile.exists()){
                fin = new FileInputStream(oldFile);
                fout = new FileOutputStream(newPath+fileName);
                byte[] buffer = new byte[fin.available()];
                if(buffer.length>0){
                    while( (byteread = fin.read(buffer)) != -1){
                        fout.write(buffer,0,byteread);
                    }
                }
                if(fin != null){
                    fin.close();
                    delFile(oldFile);
                }
            }else{
                throw new Exception("需要转移的文件不存在!");
            }
        }catch(Exception e){
            e.printStackTrace();
            throw e;
        }finally{
            if(fin != null){
                fin.close();
            }
        }
    }

    /**
     * 删除文件,只支持删除文件,不支持删除目录
     * @param file 要删除的文件
     * @throws Exception
     */
    public static void delFile(File file) throws Exception {
        if(!file.exists()) {
            throw new Exception("文件"+file.getName()+"不存在,请确认!");
        }
        if(file.isFile()){
            if(file.canWrite()){
                file.delete();
            }else{
                throw new Exception("文件"+file.getName()+"只读,无法删除,请手动删除!");
            }
        }else{
            throw new Exception("文件"+file.getName()+"不是一个标准的文件,有可能为目录,请确认!");
        }
    }


    /**
     * 导出文件
     * @param tmpPath 文件路径
     * @param contentList 导出内容
     * @param name 文件名
     * @throws IOException
     */
    public static void exportFile(Path tmpPath, List<String> contentList, String name) throws IOException {
        boolean flag1=Files.isDirectory(tmpPath);
        if (!flag1) {
            Files.createDirectory(tmpPath);
        }
        BufferedWriter bufferedWriter=Files.newBufferedWriter(Paths.get(tmpPath+File.separator+name),Charset.forName("ASCII"));
        for (String str:contentList) {
            // 写文件
            bufferedWriter.write(str);
        }
        bufferedWriter.flush();
        bufferedWriter.close();
    }

    /**
     * 获取目录下所有文件(按时间排序)
     * @param path 文件目录
     * @return 文件列表
     */
    public static List<File> getFileSort(String path) {

        List<File> list = getFiles(path, new ArrayList<File>());

        if (list != null && list.size() > 0) {

            Collections.sort(list, new Comparator<File>() {
                @Override
                public int compare(File file, File newFile) {
                    if (file.lastModified() > newFile.lastModified()) {
                        return 1;
                    } else if (file.lastModified() == newFile.lastModified()) {
                        return 0;
                    } else {
                        return -1;
                    }

                }
            });

        }

        return list;


    }

    private static List<File> getFiles(String realpath, List<File> files) {

        File realFile = new File(realpath);
        if (realFile.isDirectory()) {
            File[] subfiles = realFile.listFiles();
            for (File file : subfiles) {
                if (file.isDirectory()) {
                    getFiles(file.getAbsolutePath(), files);
                } else {
                    files.add(file);
                }
            }
        }
        return files;
    }


    /**
     * 按行读取文件内容
     * @param file
     * @return
     * @throws IOException
     */
    public static String readLineInfo (File file) throws IOException {
        String lineTxt = null;
        if (file.isFile() && file.exists()) {
            InputStreamReader read = new InputStreamReader(new FileInputStream(file));
            BufferedReader bufferedReader = new BufferedReader(read);
            lineTxt = bufferedReader.readLine();
            if (null != bufferedReader)
                bufferedReader.close();
        }
        return lineTxt;
    }
}
