package cn.witsky.utils.http;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * @author zhaoliancan
 * @description http工具类
 * @create 2019-05-15 17:27
 */
public class HttpUtils {


    /**
     * 1.发送HTTP请求，json格式数据
     * @param url  请求地址
     * @param body  json格式请求体
     * @return  字符串响应体
     * @throws Exception
     */
    public static String sendPostByJson(String url, String body) throws Exception {
        HttpPost post = null;
        String resData = null;
        CloseableHttpResponse result = null;
        CloseableHttpClient httpclient =  HttpClients.createDefault();
        try {
            post = new HttpPost(url);
            HttpEntity entity2 = new StringEntity(body, Consts.UTF_8);
            post.setHeader("Content-Type", "application/json");
            post.setEntity(entity2);
            result = httpclient.execute(post);
            if (HttpStatus.SC_OK == result.getStatusLine().getStatusCode()) {
                resData = EntityUtils.toString(result.getEntity());
            }
        }catch (Exception e){
            return "{\"code\":1}";
        }finally {
            if (result != null) {
                result.close();
            }
            if (post != null) {
                post.releaseConnection();
            }
        }
        return resData;
    }
}
